let displayValue = "";
let currentOperation = null;
let previousValue = "";

function appendNumber(number) {
  if (displayValue === "0" && number === "0") return; // Prevent multiple leading zeros
  displayValue += number;
  updateDisplay();
}

function setOperation(operation) {
  if (displayValue === "") return; // Prevent operation without a number
  if (previousValue !== "") calculate();
  currentOperation = operation;
  previousValue = displayValue;
  displayValue = "";
}

function calculate() {
  let result;
  const prev = parseFloat(previousValue);
  const current = parseFloat(displayValue);
  if (isNaN(prev) || isNaN(current)) return;

  switch (currentOperation) {
    case "+":
      result = prev + current;
      break;
    case "-":
      result = prev - current;
      break;
    case "*":
      result = prev * current;
      break;
    case "/":
      result = prev / current;
      break;
    default:
      return;
  }

  displayValue = result.toString();
  currentOperation = null;
  previousValue = "";
  updateDisplay();
}

function clearDisplay() {
  displayValue = "";
  currentOperation = null;
  previousValue = "";
  updateDisplay();
}

function updateDisplay() {
  document.getElementById("display").value = displayValue;
}
